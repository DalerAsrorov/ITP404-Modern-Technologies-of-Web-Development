#Instructions on Launching the App

##Steps

1. Navgate to the project directory (ex: cd ~/Midterm\ Project)
2. Run the server: (ex: php -S localhost:8000)
3. Go to browser and navigate to localhost: (ex: "localhost:8000")

